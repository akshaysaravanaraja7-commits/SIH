from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api.enhancement import router as enhancement_router


app = FastAPI(
    title="Lunar PSR Image Enhancement API",
    description="Backend API for lunar PSR image processing.",
    version="1.0.0",
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(enhancement_router)


app.mount(
    "/processed",
    StaticFiles(directory="processed"),
    name="processed",
)


@app.get("/")
def root():
    return {
        "message": "Lunar PSR Image Enhancement API is running.",
        "status": "operational",
    }